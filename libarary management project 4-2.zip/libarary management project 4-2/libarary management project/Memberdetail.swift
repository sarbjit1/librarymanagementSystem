//
//  Memberdetail.swift
//  libarary management project
//
//  Created by sarbjit on 12/10/17.
//  Copyright © 2017 sarbjit. All rights reserved.
//

import Foundation



class Memberdetail{
    public private(set) var MemberId:[Int] = []
    public private(set) var memberName:[String] = []
    public private(set) var CityOfMember:[String] = []
    public private(set) var status:[String] = []
    
    var actionindex : Int = 0
    
    var action : String = ""

    
    init(mId:[Int],mName:[String],cityMem:[String],tatus:[String]) {
        
        MemberId = mId
        memberName = mName
        CityOfMember = cityMem
         status = tatus
    }
    func getMid(actionindex: Int) -> Int {
        return MemberId[actionindex]
    }
    func getMname(actionindex: Int) -> String {
        return memberName[actionindex]
    }
    func getcityofmember(actionindex: Int) -> String {
        return CityOfMember[actionindex]
    }
    func getstatusofmembet(actionindex: Int) -> String {
        return status[actionindex]
    }
    
    func setmname(action : String) {
        memberName.append(action)
    }
    func setcityMem(action : String) {
        CityOfMember.append(action)
    }
  
    func setstatus(action : String) {
       status.append(action)
    }
    }






