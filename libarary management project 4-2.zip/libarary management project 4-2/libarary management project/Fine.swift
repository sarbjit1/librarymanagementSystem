//
//  Fine.swift
//  libarary management project
//
//  Created by sarbjit on 12/10/17.
//  Copyright © 2017 sarbjit. All rights reserved.
//

import Foundation

class Fine{
    public private(set) var finenumber:[Int] = []
    public private(set) var finestatus: [String] = []
    public private(set) var fineamount: [String] = []
    var actionindex : Int = 0
    
    var action : String = ""
    
    init(fineN:[Int],fineSta:[String],FAmount:[String]) {
        finenumber = fineN
         finestatus = fineSta
         fineamount = FAmount
    }
    func getfineC(actionindex: Int) -> Int {
        return finenumber[actionindex]
    }
    func getfinestaus(actionindex: Int) -> String {
        return finestatus[actionindex]
    }
    func getfineamount(actionindex: Int) -> String {
        return fineamount[actionindex]
    }
    
    func setfineamount(action : String) {
        fineamount.append(action)
    }
}
