//
//  Bookdetail.swift
//  libarary management project
//
//  Created by sarbjit on 11/10/17.
//  Copyright © 2017 sarbjit. All rights reserved.
//

import Foundation

class Bookdetail{
   public private(set) var BookCode:[Int] = []
   public private(set) var BookName:[String] = []
   public private(set) var bookCategory:[String] = []
   public private(set) var bookAuther:[String] = []
    public private(set) var Bookpublisher:[String] = []
   public private(set) var BookPublisherDate:[String] = []
   public private(set) var bookPrice:[String] = []
    var actionindex : Int = 0
    
    var action : String = ""

    
    init(bookco:[Int] , bookname:[String],Bookcatego:[String] ,bookAu:[String], bookpub:[String] , bookpubDate:[String], Bookrate:[String]) {
        BookCode = bookco
        BookName = bookname
        bookCategory = Bookcatego
        bookAuther = bookAu
        Bookpublisher = bookpub
        BookPublisherDate = bookpubDate
        bookPrice = Bookrate
       
        }
    
    func getBcode(actionindex: Int) -> Int {
        return BookCode[actionindex]
    }
    func getBname(actionindex: Int) -> String {
        return BookName[actionindex]
    }
    func getcategory(actionindex: Int) -> String {
        return bookCategory[actionindex]
    }
    func getAuther(actionindex: Int) -> String {
        return bookAuther[actionindex]
    }
    
    func getpublisher(actionindex: Int) -> String {
        return Bookpublisher[actionindex]
    }
    func getpubdate(actionindex: Int) -> String {
        return BookPublisherDate[actionindex]
    }
    func getbookprice(actionindex: Int) -> String {
        
        return bookPrice[actionindex]
    }
    
   
    func setbookname(action : String) {
        BookName.append(action)
    }
    func setcategory(bookcate:String) {
        bookCategory.append(action)
    }
    func setAuther(bookcate:String) {
        bookAuther.append(action)
    }
    
    func setpub(bookpublisher:String)  {
        Bookpublisher.append(action)
    }
    func setpubDate(publishDate:String) {
        BookPublisherDate.append(action)
    }
    func setbookprice(bkPrice:Double) {
       bookPrice.append(action)
    }
    
}
